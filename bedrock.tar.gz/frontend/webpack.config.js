
const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const webpack = require("webpack");
const Dotenv = require('dotenv-webpack');

module.exports = (env, argv) => {
  const isDevelopment = argv.mode === 'development';
  
  return {
    mode: isDevelopment ? "development" : "production", 
    entry: "./src/index.tsx",
    output: {
      path: path.resolve(__dirname, "dist"),
      filename: "bundle.js", 
      clean: true,
    },
    devServer: {
      static: path.resolve(__dirname, "dist"),
      port: 3000,
      host: "0.0.0.0",
      historyApiFallback: true,
      hot: true,
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx|ts|tsx)$/,
          exclude: /node_modules/,
          use: {
            loader: "babel-loader",
            options: {
              presets: [
                "@babel/preset-env", 
                "@babel/preset-react",
                "@babel/preset-typescript"
              ],
            },
          },
        },
        {
          test: /\.css$/,
          use: [
            "style-loader", 
            "css-loader",
          ],
        },
      ],
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: "./public/index.html",
      }),
      new Dotenv({
        path: './.env',
        safe: false,
        systemvars: true,
        silent: false,
      }),
    ],
    resolve: {
      extensions: [".js", ".jsx", ".ts", ".tsx", ".json"],
      fallback: {
        "process": require.resolve("process/browser.js"),
        "buffer": require.resolve("buffer"),
        "util": require.resolve("util/"),
        "stream": require.resolve("stream-browserify"),
      }
    },
  };
};
