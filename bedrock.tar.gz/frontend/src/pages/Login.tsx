import React from "react";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import { useNavigate } from "react-router-dom";
import { config } from "../config/env";
import { GoogleCredentialResponse } from "../types/auth";
import { decodeJwtToken, extractUserIdFromEmail } from "../utils/auth";
import { apiService } from "../services/api";

const ClientSideIDTokenFlow: React.FC = () => {
  const navigate = useNavigate();

  const handleLoginSuccess = async (credentialResponse: GoogleCredentialResponse): Promise<void> => {
    try {
      if (!credentialResponse.credential) {
        throw new Error('No credential received from Google');
      }

      const idToken = credentialResponse.credential;
      console.log("Google Login Success");

      // JWT 토큰에서 사용자 정보 추출 (클라이언트 사이드 검증)
      const userInfo = decodeJwtToken(idToken);
      console.log("User Info:", {
        email: userInfo.email,
        name: userInfo.name
      });

      // 백엔드 서버 인증 (운영환경에서 사용)
      try {
        const authResponse = await apiService.verifyGoogleToken(idToken);
        console.log("Server verification success:", authResponse);
        
        // 서버 검증 성공 시 사용자 ID로 워크스페이스 이동
        const userId = authResponse.user_info.user_id;
        navigate(`/${userId}`);
      } catch (serverError) {
        console.warn("Server verification failed, using client-side info:", serverError);
        
        // 서버 검증 실패 시 클라이언트 사이드 정보로 대체
        const userId = extractUserIdFromEmail(userInfo.email);
        navigate(`/${userId}`);
      }
      
    } catch (error) {
      console.error("Login processing failed:", error);
      alert("로그인 처리 중 오류가 발생했습니다. 다시 시도해주세요.");
    }
  };

  const handleLoginError = (): void => {
    console.error("Google Login Failed");
    alert("Google 로그인에 실패했습니다. 네트워크 연결을 확인하고 다시 시도해주세요.");
  };

  return (
    <GoogleOAuthProvider clientId={config.googleClientId}>
      <div style={{ 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center', 
        justifyContent: 'center', 
        height: '100vh',
        gap: '20px',
        backgroundColor: '#f5f5f5',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      }}>
        <div style={{
          backgroundColor: 'white',
          padding: '40px',
          borderRadius: '12px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          maxWidth: '400px',
          width: '100%'
        }}>
          <h1 style={{ 
            color: '#333', 
            marginBottom: '10px',
            fontSize: '28px',
            fontWeight: '600'
          }}>
            🪨 BedRock Planner
          </h1>
          <p style={{ 
            color: '#666', 
            marginBottom: '30px',
            fontSize: '16px',
            lineHeight: '1.5'
          }}>
            드래그 앤 드롭으로 일정을 시각적으로 관리하세요
          </p>
          
          <GoogleLogin
            onSuccess={handleLoginSuccess}
            onError={handleLoginError}
            theme="filled_blue"
            size="large"
            text="signin_with"
            shape="rectangular"
            width="100%"
          />
          
          <div style={{ 
            marginTop: '20px', 
            fontSize: '12px', 
            color: '#999',
            lineHeight: '1.4'
          }}>
            Google 계정으로 안전하게 로그인하세요<br/>
            {process.env.NODE_ENV === 'development' && (
              <span style={{ color: '#f39c12' }}>
                개발 환경: {config.frontendUrl}
              </span>
            )}
          </div>
        </div>
      </div>
    </GoogleOAuthProvider>
  );
};

const AuthorizationCodeFlow: React.FC = () => {
  return (
    <div>
      <h1>Authorization Code Flow</h1>
      <p>Implement the Authorization Code Flow here.</p>
    </div>
  );
};

// Default export 추가
const Login: React.FC = () => {
  return <ClientSideIDTokenFlow />;
};

export { ClientSideIDTokenFlow };
export default Login;
